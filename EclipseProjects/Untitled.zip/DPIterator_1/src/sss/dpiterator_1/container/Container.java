package sss.dpiterator_1.container;

public interface Container {
	public Iterator getIterator();
}
