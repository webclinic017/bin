package sss.bounded_wildcard.d;

//Three-dimensional coordinates.
public class ThreeD extends TwoD {
	public int z;
	public ThreeD(int a, int b, int c) {
		super(a, b);
		z = c;
	}
}
