package sss.bounded_wildcard.d;

//Two-dimensional coordinates.
public class TwoD {
	public int x, y;
	public TwoD(int a, int b) {
		x = a;
		y = b;
	}
}
