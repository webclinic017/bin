package sss.dpbuilder_1.packing;

public interface Packing {
	public String pack();
}
