package sss.dpstate_1.state;

import sss.dpstate_1.context.Context;

public interface State {
	public void doAction(Context context);
}
