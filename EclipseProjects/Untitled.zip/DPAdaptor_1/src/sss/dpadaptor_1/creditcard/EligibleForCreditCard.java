package sss.dpadaptor_1.creditcard;

public interface EligibleForCreditCard {
	public void giveBankDetails();  
	public String getCreditCard();  
}
