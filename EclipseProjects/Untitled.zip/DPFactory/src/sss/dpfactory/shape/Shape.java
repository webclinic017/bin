package sss.dpfactory.shape;

public interface Shape {
	void draw();
}
