package sss.matrixspiral.object_oriented;

public enum StartPosition {
	TOP_LEFT, TOP_RIGHT, BOTTTOM_RIGHT, BOTTOM_LEFT;
}
