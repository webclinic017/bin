package sss.matrixspiral.object_oriented;

public enum TraverseDirection {
	UP, DOWN, RIGHT, LEFT;
}
