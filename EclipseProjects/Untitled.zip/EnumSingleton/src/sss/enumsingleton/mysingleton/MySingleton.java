package sss.enumsingleton.mysingleton;

interface MySingleton {
	public void sayHello();
	public void sayBye();
}
