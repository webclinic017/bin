package sss.dpchain_of_responsibility.logger;

public enum LogLevel {
	INFO, DEBUG, ERROR
}
