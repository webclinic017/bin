package com.moglilabs.payment.application;

import com.moglilabs.validator.validation.ResponseCode;

public class ResponseCodes extends ResponseCode {
	
	public static ResponseCode INVALID_REQUIRED_PARAMETERS = new ResponseCode(10001, "REQUIRED PARAMETERS ARE INVALID");
	public static ResponseCode DUPLICATE_PAYMENT_CODE = new ResponseCode(10002, "PAYMENT CODE IS DUPLICATE");
	public static ResponseCode INVALID_PAYMENT_ID = new ResponseCode(10003, "PAYMENT ID IS INVALID");

	public ResponseCodes(int code, String message) {
		super(code, message);
	}
}
