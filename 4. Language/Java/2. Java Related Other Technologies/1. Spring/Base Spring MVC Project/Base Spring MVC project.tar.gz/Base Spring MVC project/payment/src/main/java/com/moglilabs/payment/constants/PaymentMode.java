package com.moglilabs.payment.constants;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

public enum PaymentMode {
     CASH(10),
     NEFT(20),
     RTGS(30),
     CHEQUE(40);
	

     private static final Map<Integer,PaymentMode> lookup 
          = new HashMap<Integer,PaymentMode>();

     static {
          for(PaymentMode s : EnumSet.allOf(PaymentMode.class))
               lookup.put(s.getCode(), s);
     }

     private int code;

     private PaymentMode(int code) {
          this.code = code;
     }

     public int getCode() { return code; }

     public static PaymentMode get(int code) { 
          return lookup.get(code); 
     }
}
