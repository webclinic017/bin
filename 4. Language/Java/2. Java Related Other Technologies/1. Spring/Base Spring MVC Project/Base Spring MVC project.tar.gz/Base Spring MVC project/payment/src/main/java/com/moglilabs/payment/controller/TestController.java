package com.moglilabs.payment.controller;

import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;

@Component
@RequestMapping(value = "/test/*")
public class TestController {
	
}
