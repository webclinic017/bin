package com.moglilabs.payment.application;

import java.util.Date;

import com.moglilabs.common.date.DateUtil;

public abstract class AppEntityDto {

	protected String createdOn;
	protected String updatedOn;

	public AppEntityDto() {

	}

	public AppEntityDto(Date createdOn, Date updatedOn) {
		this.createdOn = DateUtil.convertDateToString(createdOn, null);
		this.updatedOn = DateUtil.convertDateToString(updatedOn, null);
	}

	public String getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}

	public String getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(String updatedOn) {
		this.updatedOn = updatedOn;
	}

}
