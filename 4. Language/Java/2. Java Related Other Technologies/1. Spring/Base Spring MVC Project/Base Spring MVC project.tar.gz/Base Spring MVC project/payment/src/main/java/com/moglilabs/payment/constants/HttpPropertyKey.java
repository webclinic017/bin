package com.moglilabs.payment.constants;

public class HttpPropertyKey {
	//public static String PRODUCTS_URL = "http.products.url";
}
