package com.moglilabs.payment.application;

public class EntityTableMap {
	public static final String PAYMENT = "payment_payment";
	public static final String PAYMENT_ITEM= "payment_payment_item";
}
