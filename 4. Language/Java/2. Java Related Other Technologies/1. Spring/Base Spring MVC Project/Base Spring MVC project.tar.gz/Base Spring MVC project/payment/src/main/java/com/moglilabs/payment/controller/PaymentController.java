package com.moglilabs.payment.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.moglilabs.payment.application.AppController;
import com.moglilabs.payment.request.AddPaymentRequest;
import com.moglilabs.payment.request.GetAllPaymentRequest;
import com.moglilabs.payment.request.GetPaymentRequest;
import com.moglilabs.payment.request.UpdatePaymentRequest;
import com.moglilabs.payment.response.AddPaymentResponse;
import com.moglilabs.payment.response.GetAllPaymentResponse;
import com.moglilabs.payment.response.GetPaymentResponse;
import com.moglilabs.payment.response.UpdatePaymentResponse;
import com.moglilabs.payment.service.IPaymentService;
import com.moglilabs.validator.exception.MoglixException;

@RestController
@RequestMapping(value = "/payment/*")
public class PaymentController extends AppController {

	private final String moduleName = "Payment";
	
	@Autowired
	IPaymentService paymentService;
		
	@Override
	public String getModuleName() {
		// TODO Auto-generated method stub
		return moduleName;
	}
	
	@RequestMapping(value = "add", method = RequestMethod.POST)
	public @ResponseBody AddPaymentResponse createPayment(@RequestBody AddPaymentRequest request) throws MoglixException {
		return paymentService.addPayment(request);
	}
	
	@RequestMapping(value = "update", method = RequestMethod.POST)
	public @ResponseBody UpdatePaymentResponse updatePayment(@RequestBody UpdatePaymentRequest request) {
		return paymentService.updatePayment(request);
	}

	@RequestMapping(value = "getById", method = RequestMethod.POST)
	public @ResponseBody GetPaymentResponse getPaymentById(@RequestBody GetPaymentRequest request) {
		return paymentService.getPayment(request);
	}
	
	@RequestMapping(value = "getAll", method = RequestMethod.POST)
	public @ResponseBody GetAllPaymentResponse getAllPayment(@RequestBody GetAllPaymentRequest request) {
		return paymentService.getAllPayment(request);
	}
}
