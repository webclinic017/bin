CREATE DATABASE  IF NOT EXISTS `buzz_sap` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `buzz_sap`;

CREATE TABLE `payment_payment` (
  `id` int(12) unsigned NOT NULL AUTO_INCREMENT,
  `ref_no` varchar(45),
  `company_id` int(12) unsigned not null,
  `plant_id` int(12) unsigned not null,
  `created_by` int(12) unsigned not null,
  `seller_id` int(12) unsigned not null,
  `seller_name` varchar(45),
  `amount` decimal(13,4) unsigned not null,
  `currency` varchar(45),
  `mode` smallint unsigned,
  `payment_date` timestamp,
  `customer_doc_no` varchar(45),
  `reference_doc` varchar(45),
  `status` smallint unsigned,
  `remark` varchar(255),
  `ip` varchar(45),
  `is_deleted` tinyint(1) unsigned DEFAULT '0',
  `created_on` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_on` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

