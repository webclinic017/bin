package com.moglilabs.payment.constants;

public class ApplicationConstant {

	public static String DESC = "desc";
    public static String ASC =	"asc";
    public static Integer DEFAULT_PAGE_SIZE = 10;
    public static String API_DATE_FORMAT  = "yyyy-MM-dd HH:mm:ss";
    public static String URL_SEPERATOR  = "/";
    public static Integer[] MOGLIX_ID = new Integer[]{1, 44};
    
    public static String PAYMENT_PREFIX = "PAY";
}

