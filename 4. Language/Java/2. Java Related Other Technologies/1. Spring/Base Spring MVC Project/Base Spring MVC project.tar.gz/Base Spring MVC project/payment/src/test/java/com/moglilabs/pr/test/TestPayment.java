package com.moglilabs.pr.test;

import org.springframework.beans.factory.annotation.Autowired;

import com.moglilabs.payment.service.IPaymentService;

public class TestPayment extends AbstractTest {

	@Autowired
	IPaymentService paymentService;

}
