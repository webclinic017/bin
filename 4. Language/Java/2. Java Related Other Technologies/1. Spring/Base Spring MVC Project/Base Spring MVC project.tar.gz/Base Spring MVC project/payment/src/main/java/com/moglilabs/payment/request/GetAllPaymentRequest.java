package com.moglilabs.payment.request;

import java.util.Date;

import com.moglilabs.validator.request.SearchRequest;
import com.moglilabs.validator.request.ServiceRequest;

public class GetAllPaymentRequest extends ServiceRequest {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8108423974965206093L;

	private String refNo;
	private Integer plantId;
	private Integer companyId;
	private Integer createdBy;
	private Date createdOn1;
	private Date createdOn2;

	private SearchRequest search;

	public Integer getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public String getRefNo() {
		return refNo;
	}

	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}

	public Integer getPlantId() {
		return plantId;
	}

	public void setPlantId(Integer plantId) {
		this.plantId = plantId;
	}

	public SearchRequest getSearch() {
		return search;
	}

	public void setSearch(SearchRequest search) {
		this.search = search;
	}

	public Date getCreatedOn1() {
		return createdOn1;
	}

	public void setCreatedOn1(Date createdOn1) {
		this.createdOn1 = createdOn1;
	}

	public Date getCreatedOn2() {
		return createdOn2;
	}

	public void setCreatedOn2(Date createdOn2) {
		this.createdOn2 = createdOn2;
	}

}
