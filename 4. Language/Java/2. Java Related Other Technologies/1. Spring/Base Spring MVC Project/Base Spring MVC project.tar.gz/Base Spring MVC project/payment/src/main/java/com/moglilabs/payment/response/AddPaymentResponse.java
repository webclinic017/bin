package com.moglilabs.payment.response;

import com.moglilabs.payment.dto.PaymentDto;
import com.moglilabs.validator.response.ServiceResponse;

public class AddPaymentResponse extends ServiceResponse {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3241801023249691760L;
	private PaymentDto payment;


	public PaymentDto getPayment() {
		return payment;
	}

	public void setPayment(PaymentDto payment) {
		this.payment = payment;
	}


}
