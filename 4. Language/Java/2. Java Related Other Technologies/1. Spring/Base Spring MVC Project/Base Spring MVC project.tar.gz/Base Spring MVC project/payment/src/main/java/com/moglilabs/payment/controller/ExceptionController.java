/*
 *  @copyright MogliLabs
 */
package com.moglilabs.payment.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.moglilabs.validator.exception.MoglixException;
import com.moglilabs.validator.response.ServiceResponse;
import com.moglilabs.validator.validation.WsError;

/**
 * 
 * @author Mohit Garg<mohit.garg@moglix.com>
 * @created_on 01-Oct-2015
 */

@ControllerAdvice
public class ExceptionController {

    @ExceptionHandler(MoglixException.class)
    public @ResponseBody ServiceResponse handleFeedException(MoglixException ex) {

        return new ServiceResponse(ex);
    }

    @ExceptionHandler(Exception.class)
    public @ResponseBody ServiceResponse handleException(Exception exception) {
    	exception.printStackTrace();
    	WsError error = new WsError();
    	error.setCode(500);
    	error.setDescription("Unknown Error Occured");
    	List<WsError> errors = new ArrayList<WsError>();
    	errors.add(error);
        MoglixException ex = new MoglixException(errors);
        return new ServiceResponse(ex);
    }

}
