package com.moglilabs.payment.response;

import com.moglilabs.payment.dto.PaymentDto;
import com.moglilabs.validator.response.ServiceResponse;

public class GetPaymentResponse extends ServiceResponse {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5940960448149658525L;

	private PaymentDto payment;


	public PaymentDto getPayment() {
		return payment;
	}

	public void setPayment(PaymentDto payment) {
		this.payment = payment;
	}

	
}
