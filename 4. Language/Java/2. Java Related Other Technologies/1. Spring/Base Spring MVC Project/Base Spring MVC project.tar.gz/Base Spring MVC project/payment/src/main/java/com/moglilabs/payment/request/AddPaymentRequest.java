package com.moglilabs.payment.request;

import javax.validation.constraints.NotNull;

import com.moglilabs.validator.request.ServiceRequest;

public class AddPaymentRequest extends ServiceRequest {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5019785874922329941L;

	@NotNull
	private Integer companyId;

	@NotNull
	private Integer createdBy;

	@NotNull
	private Integer plantId;

	@NotNull
	private Double amount;
	private String currency;
	private Integer mode;
	private String paymentDate;
	private Boolean isDeleted = false;

	@NotNull
	private Integer sellerId;

	private String sellerName;

	private String customerDocNo;
	private String remark;
	private String referenceDoc;
	private String ip;


	public Integer getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getReferenceDoc() {
		return referenceDoc;
	}

	public void setReferenceDoc(String referenceDoc) {
		this.referenceDoc = referenceDoc;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public Integer getPlantId() {
		return plantId;
	}

	public void setPlantId(Integer plantId) {
		this.plantId = plantId;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public Integer getMode() {
		return mode;
	}

	public void setMode(Integer mode) {
		this.mode = mode;
	}

	public String getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}

	public Boolean getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public Integer getSellerId() {
		return sellerId;
	}

	public void setSellerId(Integer sellerId) {
		this.sellerId = sellerId;
	}

	public String getSellerName() {
		return sellerName;
	}

	public void setSellerName(String sellerName) {
		this.sellerName = sellerName;
	}

	public String getCustomerDocNo() {
		return customerDocNo;
	}

	public void setCustomerDocNo(String customerDocNo) {
		this.customerDocNo = customerDocNo;
	}

}
