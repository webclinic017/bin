package com.moglilabs.payment.dao;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.moglilabs.payment.entity.Payment;
import com.moglilabs.payment.request.GetAllPaymentRequest;
import com.moglilabs.validator.request.SearchRequest;

@Repository
public class PaymentDao {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public Payment create(Payment obj) {
		sessionFactory.getCurrentSession().persist(obj);
		return obj;
	}
	
	public Payment getById(Integer id) {
		Query query = sessionFactory.getCurrentSession().createQuery("from Payment obj where obj.id = :id");
        query.setParameter("id", id);
        return (Payment) query.uniqueResult();
	}
	
	public Payment getByRef(String refNo) {
		Query query = sessionFactory.getCurrentSession().createQuery("from Payment obj where obj.refNo = :refNo");
        query.setParameter("refNo", refNo);
        return (Payment) query.uniqueResult();
	}
	
	public Payment update(Payment payment) {
		payment.setUpdatedOn(new Date());
		sessionFactory.getCurrentSession().merge(payment);
		return payment;
	}

	public List<Payment> getAll() {
		return getAll(new GetAllPaymentRequest());
	}
	
	public Long countAll(GetAllPaymentRequest request) {
		Criteria c = prepareCriteriaForPayment(request);
		return (long) c.list().size();
	}
	
	@SuppressWarnings("unchecked")
	public List<Payment> getAll(GetAllPaymentRequest request) {
		Criteria c = prepareCriteriaForPayment(request);
		if(request.getSearch() != null) {
			SearchRequest option = request.getSearch();
			if(option.getOrder().equals("desc")){
				c.addOrder(Order.desc(option.getOrderBy()));	
			} else {
				c.addOrder(Order.asc(option.getOrderBy()));
			}
			c.setFirstResult((option.getPageNumber() - 1) * option.getPageSize());
			c.setMaxResults(option.getPageSize());
		}		
		return (List<Payment>)c.list();
	}
	
	private Criteria prepareCriteriaForPayment(GetAllPaymentRequest request) {		
		Criteria c = sessionFactory.getCurrentSession().createCriteria(Payment.class, "p");
		c.add(Restrictions.eq("isDeleted", false));
		
		if(StringUtils.isNotBlank(request.getRefNo())) {
			c.add(Restrictions.eq("refNo", request.getRefNo().trim()));
		}
		if(request.getPlantId() != null) {
			c.add(Restrictions.eq("plantId", request.getPlantId()));
		}
		if(request.getCompanyId() != null) {
			c.add(Restrictions.eq("companyId", request.getCompanyId()));
		}
		if(request.getCreatedBy() != null) {
			c.add(Restrictions.eq("createdBy", request.getCreatedBy()));
		}
		if(request.getCreatedOn1() != null) {
			c.add(Restrictions.ge("createdOn", request.getCreatedOn1()));
		}
		if(request.getCreatedOn2() != null) {
			c.add(Restrictions.le("createdOn", request.getCreatedOn2()));
		}
		return c;
	}
	
}
