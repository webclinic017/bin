package com.moglilabs.payment.constants;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

public enum PaymentStatus {
     INITIATED(10),
     APPROVED(20);

     private static final Map<Integer,PaymentStatus> lookup 
          = new HashMap<Integer,PaymentStatus>();

     static {
          for(PaymentStatus s : EnumSet.allOf(PaymentStatus.class))
               lookup.put(s.getCode(), s);
     }

     private int code;

     private PaymentStatus(int code) {
          this.code = code;
     }

     public int getCode() { return code; }

     public static PaymentStatus get(int code) { 
          return lookup.get(code); 
     }
}
