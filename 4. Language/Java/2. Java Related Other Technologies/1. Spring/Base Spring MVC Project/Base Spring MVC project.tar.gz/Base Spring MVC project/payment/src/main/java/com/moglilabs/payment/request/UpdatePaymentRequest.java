package com.moglilabs.payment.request;

import javax.validation.constraints.NotNull;

import com.moglilabs.validator.request.ServiceRequest;

public class UpdatePaymentRequest extends ServiceRequest {

	/**
	 * 
	 */
	private static final long serialVersionUID = 629790344772541754L;

	@NotNull
	private Integer id;

	private String paymentDate;
	private Boolean isDeleted;
	private String remark;
	private Integer status;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}

	public Boolean getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

}
