package com.moglilabs.payment.object.mapper;

import org.springframework.stereotype.Component;

import com.moglilabs.common.date.DateUtil;
import com.moglilabs.payment.constants.ApplicationConstant;
import com.moglilabs.payment.constants.PaymentStatus;
import com.moglilabs.payment.dto.PaymentDto;
import com.moglilabs.payment.entity.Payment;
import com.moglilabs.payment.request.AddPaymentRequest;
import com.moglilabs.payment.request.UpdatePaymentRequest;

@Component
public class PaymentObjectMapper {
	
	public Payment fromRequestToPayment(AddPaymentRequest request) {
		Payment payment = new Payment(); 
		payment.setCompanyId(request.getCompanyId());
		payment.setCreatedBy(request.getCreatedBy());
		payment.setPlantId(request.getPlantId());
		payment.setAmount(request.getAmount());
		payment.setCurrency(request.getCurrency());
		payment.setMode(request.getMode());
		payment.setPaymentDate(DateUtil.convertStringToDate(request.getPaymentDate(), ApplicationConstant.API_DATE_FORMAT));
		payment.setIsDeleted(request.getIsDeleted());
		payment.setSellerId(request.getSellerId());
		payment.setSellerName(request.getSellerName());
		payment.setCustomerDocNo(request.getCustomerDocNo());
		payment.setReferenceDoc(request.getReferenceDoc());
		payment.setRemark(request.getRemark());
		payment.setIp(request.getIp());
		payment.setStatus(PaymentStatus.INITIATED.getCode());
		return payment;
	}
	
	public Payment fromUpdateRequestToPayment(UpdatePaymentRequest request, Payment payment) {
		payment.setPaymentDate(DateUtil.convertStringToDate(request.getPaymentDate(), ApplicationConstant.API_DATE_FORMAT));
		payment.setIsDeleted(request.getIsDeleted());
		payment.setRemark(request.getRemark());
		payment.setStatus(request.getStatus());
		return payment;
	}
	
	public PaymentDto fromPaymentToPaymentDto(Payment payment) {
		PaymentDto paymentDto = new PaymentDto(payment); 
		return paymentDto;
	}
	
}
