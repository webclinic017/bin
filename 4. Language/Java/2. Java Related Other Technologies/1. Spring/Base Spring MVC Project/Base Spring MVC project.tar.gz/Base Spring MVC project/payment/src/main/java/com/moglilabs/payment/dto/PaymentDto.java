package com.moglilabs.payment.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.moglilabs.payment.application.AppEntityDto;
import com.moglilabs.payment.constants.PaymentMode;
import com.moglilabs.payment.constants.PaymentStatus;
import com.moglilabs.payment.entity.Payment;

public class PaymentDto extends AppEntityDto {

	private Integer id;
	private String refNo;
	private String status;
	private Double amount;
	private String currency;
	private String mode;
	private Integer companyId;
	private Integer createdBy;
	private Date paymentDate;
	private Boolean isDeleted;
	private Integer sellerId;
	private String sellerName;
	private String customerDocNo;
	private Integer plantId;
	private String remark;
	private String referenceDoc;
	private String ip;

	public PaymentDto() {

	}

	public PaymentDto(Payment payment) {
		super(payment.getCreatedOn(), payment.getUpdatedOn());
		this.id = payment.getId();
		this.refNo = payment.getRefNo();
		this.status = PaymentStatus.get(payment.getStatus()).name();
		this.amount = payment.getAmount();
		this.currency = payment.getCurrency();
		this.mode = PaymentMode.get(payment.getMode()).name();
		this.companyId = payment.getCompanyId();
		this.createdBy = payment.getCreatedBy();
		this.paymentDate = payment.getPaymentDate();
		this.isDeleted = payment.getIsDeleted();
		this.sellerId = payment.getSellerId();
		this.sellerName = payment.getSellerName();
		this.customerDocNo = payment.getCustomerDocNo();
		this.plantId = payment.getPlantId();
		this.remark = payment.getRemark();
		this.referenceDoc = payment.getReferenceDoc();
		this.ip = payment.getIp();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getRefNo() {
		return refNo;
	}

	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public Integer getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Date getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}

	public Boolean getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public Integer getSellerId() {
		return sellerId;
	}

	public void setSellerId(Integer sellerId) {
		this.sellerId = sellerId;
	}

	public String getSellerName() {
		return sellerName;
	}

	public void setSellerName(String sellerName) {
		this.sellerName = sellerName;
	}

	public String getCustomerDocNo() {
		return customerDocNo;
	}

	public void setCustomerDocNo(String customerDocNo) {
		this.customerDocNo = customerDocNo;
	}

	public Integer getPlantId() {
		return plantId;
	}

	public void setPlantId(Integer plantId) {
		this.plantId = plantId;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getReferenceDoc() {
		return referenceDoc;
	}

	public void setReferenceDoc(String referenceDoc) {
		this.referenceDoc = referenceDoc;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}


}
