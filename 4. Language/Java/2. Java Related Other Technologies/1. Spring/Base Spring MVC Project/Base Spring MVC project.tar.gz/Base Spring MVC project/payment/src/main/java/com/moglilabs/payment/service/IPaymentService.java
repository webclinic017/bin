package com.moglilabs.payment.service;

import java.util.List;

import com.moglilabs.payment.entity.Payment;
import com.moglilabs.payment.request.AddPaymentRequest;
import com.moglilabs.payment.request.GetAllPaymentRequest;
import com.moglilabs.payment.request.GetPaymentRequest;
import com.moglilabs.payment.request.UpdatePaymentRequest;
import com.moglilabs.payment.response.AddPaymentResponse;
import com.moglilabs.payment.response.GetAllPaymentResponse;
import com.moglilabs.payment.response.GetPaymentResponse;
import com.moglilabs.payment.response.UpdatePaymentResponse;
import com.moglilabs.validator.exception.MoglixException;

public interface IPaymentService {
	
	public Payment addPayment(Payment obj);
	public Payment updatePayment(Payment obj);
	public Payment getPaymentById(Integer id);
	public Payment getPaymentByRef(String refNo);
	public List<Payment> getAllPayment();
	
	public AddPaymentResponse addPayment(AddPaymentRequest request) throws MoglixException;
	public GetPaymentResponse getPayment(GetPaymentRequest request);
	public GetAllPaymentResponse getAllPayment(GetAllPaymentRequest request);
	public UpdatePaymentResponse updatePayment(UpdatePaymentRequest request);

}
