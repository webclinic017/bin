package com.moglilabs.payment.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.moglilabs.http.IHttpUtil;
import com.moglilabs.http.impl.HttpUtilImpl;
import com.moglilabs.payment.application.ResponseCodes;
import com.moglilabs.payment.constants.ApplicationConstant;
import com.moglilabs.payment.dao.PaymentDao;
import com.moglilabs.payment.dto.PaymentDto;
import com.moglilabs.payment.entity.Payment;
import com.moglilabs.payment.object.mapper.PaymentObjectMapper;
import com.moglilabs.payment.request.AddPaymentRequest;
import com.moglilabs.payment.request.GetAllPaymentRequest;
import com.moglilabs.payment.request.GetPaymentRequest;
import com.moglilabs.payment.request.UpdatePaymentRequest;
import com.moglilabs.payment.response.AddPaymentResponse;
import com.moglilabs.payment.response.GetAllPaymentResponse;
import com.moglilabs.payment.response.GetPaymentResponse;
import com.moglilabs.payment.response.UpdatePaymentResponse;
import com.moglilabs.payment.service.IPaymentService;
import com.moglilabs.validator.exception.MoglixException;
import com.moglilabs.validator.response.SearchResponse;
import com.moglilabs.validator.validation.ValidationContext;

@Service
public class PaymentServiceImpl implements IPaymentService {
	
	@Autowired
	PaymentDao dao;
	
	@Autowired
	PaymentObjectMapper mapper;
	
	
	@SuppressWarnings("rawtypes")
	IHttpUtil http = new HttpUtilImpl();
	
	@Override
	@Transactional
	public Payment addPayment(Payment obj) {
		return dao.create(obj);
	}
	
	@Override
	@Transactional
	public Payment updatePayment(Payment obj) {
		return dao.update(obj);
	}
	
	@Override
	@Transactional
	public Payment getPaymentById(Integer id) {
		return dao.getById(id);
	}
	
	@Override
	@Transactional
	public Payment getPaymentByRef(String ref) {
		return dao.getByRef(ref);
	}
	
	@Override
	@Transactional
	public List<Payment> getAllPayment() {
		return dao.getAll();
	}
	
	@Override
	@Transactional(rollbackFor = Exception.class)
	public AddPaymentResponse addPayment(AddPaymentRequest request)  throws MoglixException {
		AddPaymentResponse response = new AddPaymentResponse();
		ValidationContext context = request.validate();
		if(!context.hasErrors()) {
			Payment payment = null;
			payment = mapper.fromRequestToPayment(request);
			payment = addPayment(payment);
			
			String refNo = ApplicationConstant.PAYMENT_PREFIX + String.format("%08d", payment.getId());
			payment.setRefNo(refNo);
			
			payment = updatePayment(payment);
			
			response.setPayment(mapper.fromPaymentToPaymentDto(payment));
			
			response.setSuccessful(true);
			response.setMessage("Payment created successfully with id: " + payment.getId());
		}
		response.setErrors(context.getErrors());
		return response;
	}
	
	@Override
	@Transactional
	public GetPaymentResponse getPayment(GetPaymentRequest request) {
		GetPaymentResponse response = new GetPaymentResponse();
		ValidationContext context = request.validate();
		if(!context.hasErrors()) {
			Payment payment = getPaymentById(request.getId());
			if(payment != null) {
				response.setPayment(mapper.fromPaymentToPaymentDto(payment));
				response.setSuccessful(true);
				response.setMessage("Payment fetched successfully with id: " + payment.getId());
			} else {
				context.addError(ResponseCodes.INVALID_PAYMENT_ID, "Payment details not found");
			}
		}
		response.setErrors(context.getErrors());
		return response;
	}
	
	@Override
	@Transactional
	public GetAllPaymentResponse getAllPayment(GetAllPaymentRequest request) {
		GetAllPaymentResponse response = new GetAllPaymentResponse();
		ValidationContext context = request.validate();
		if(!context.hasErrors()) {
			List<Payment> payments = new ArrayList<Payment>();
			payments = dao.getAll(request);
			List<PaymentDto> paymentDtos = new ArrayList<PaymentDto>();
			for(Payment payment : payments) {
				paymentDtos.add(mapper.fromPaymentToPaymentDto(payment));
			}
			response.setElements(paymentDtos);
			if(request.getSearch() != null) {
				Long total = dao.countAll(request);
				response.setSearch(new SearchResponse(total,request.getSearch().getPageNumber(), request.getSearch().getPageSize(), response.getElements().size()));
			}
			response.setSuccessful(true);
			response.setMessage("Payments fetched successfully : " + payments.size());
		}
		response.setErrors(context.getErrors());
		return response;
	}
	
	@Override
	@Transactional
	public UpdatePaymentResponse updatePayment(UpdatePaymentRequest request) {
		UpdatePaymentResponse response = new UpdatePaymentResponse();
		ValidationContext context = request.validate();
		if(!context.hasErrors()) {
			Payment payment = getPaymentById(request.getId());
			if(payment != null) {
				payment = mapper.fromUpdateRequestToPayment(request, payment);
				payment = updatePayment(payment);
				response.setPayment(mapper.fromPaymentToPaymentDto(payment));
				response.setSuccessful(true);
				response.setMessage("Payment updated successfully with id: " + payment.getId());
			} else {
				context.addError(ResponseCodes.INVALID_PAYMENT_ID, "Payment details not found");
			}
		}
		response.setErrors(context.getErrors());
		return response;
	}

}
