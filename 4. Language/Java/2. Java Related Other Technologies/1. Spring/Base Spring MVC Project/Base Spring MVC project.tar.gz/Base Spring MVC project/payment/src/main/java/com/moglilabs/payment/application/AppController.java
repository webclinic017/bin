package com.moglilabs.payment.application;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


public abstract class AppController {

	public abstract String getModuleName();
	
	@RequestMapping(value = "ping", method = RequestMethod.GET)
	public String ping(){
		return "Hello welcome to "+getModuleName();
	}
}
