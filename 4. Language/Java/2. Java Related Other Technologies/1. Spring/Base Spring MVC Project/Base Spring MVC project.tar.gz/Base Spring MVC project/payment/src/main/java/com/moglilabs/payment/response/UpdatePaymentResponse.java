package com.moglilabs.payment.response;

import com.moglilabs.payment.dto.PaymentDto;
import com.moglilabs.validator.response.ServiceResponse;

public class UpdatePaymentResponse extends ServiceResponse {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3209135266514288462L;

	private PaymentDto payment;


	public PaymentDto getPayment() {
		return payment;
	}

	public void setPayment(PaymentDto payment) {
		this.payment = payment;
	}


}
