package com.moglilabs.payment.response;

import java.util.ArrayList;
import java.util.List;

import com.moglilabs.payment.dto.PaymentDto;
import com.moglilabs.validator.response.SearchResponse;
import com.moglilabs.validator.response.ServiceResponse;

public class GetAllPaymentResponse extends ServiceResponse {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7634316720256741840L;

	private List<PaymentDto> elements = new ArrayList<PaymentDto>();

	private SearchResponse search;

	public List<PaymentDto> getElements() {
		return elements;
	}

	public void setElements(List<PaymentDto> elements) {
		this.elements = elements;
	}

	public SearchResponse getSearch() {
		return search;
	}

	public void setSearch(SearchResponse search) {
		this.search = search;
	}

}
