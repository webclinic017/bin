package com.moglilabs.payment.request;

import javax.validation.constraints.NotNull;

import com.moglilabs.validator.request.ServiceRequest;

public class GetPaymentRequest extends ServiceRequest {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5080742523329974492L;

	@NotNull
	private Integer id;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

}
