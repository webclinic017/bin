package com.moglilabs.payment.constants;

import java.util.Properties;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class HttpProperty {
	
	@Autowired
    private Properties httpProperties;

	//public static String PRODUCTS_URL;
	
	@SuppressWarnings("restriction")
	@PostConstruct
	public void init(){
		//PRODUCTS_URL = httpProperties.getProperty(HttpPropertyKey.PRODUCTS_URL);
	}
}
