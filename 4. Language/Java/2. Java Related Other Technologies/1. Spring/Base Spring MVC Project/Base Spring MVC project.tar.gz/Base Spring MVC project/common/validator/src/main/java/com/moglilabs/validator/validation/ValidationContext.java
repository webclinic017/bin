package com.moglilabs.validator.validation;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ValidationContext {

    private final List<WsError>   errors   = new ArrayList<WsError>();
    private final List<WsWarning> warnings = new ArrayList<WsWarning>();

    public void addError(ResponseCode responseCode) {
    	addError(responseCode, responseCode.message(), null);
    }

    public void addErrors(List<WsError> errors) {
        this.errors.addAll(errors);
    }

    public void addError(ResponseCode responseCode, String description) {
    	addError(responseCode, description, null);
    }

    public void addError(ResponseCode responseCode, String description, Map<String, String> errorParams) {
        this.errors.add(new WsError(responseCode.code(), responseCode.message(), description, errorParams));
    }

    public List<WsError> getErrors() {
        return errors;
    }

    public void addWarning(ResponseCode responseCode) {
        this.warnings.add(new WsWarning(responseCode.code(), responseCode.message()));
    }

    public void addWarning(ResponseCode responseCode, String description) {
        this.warnings.add(new WsWarning(responseCode.code(), responseCode.message(), description));
    }

    public List<WsWarning> getWarnings() {
        return warnings;
    }

    public boolean hasErrors() {
        return errors.size() > 0;
    }

    /**
     * @return
     */
    public boolean hasWarnings() {
        return warnings.size() > 0;
    }
}
