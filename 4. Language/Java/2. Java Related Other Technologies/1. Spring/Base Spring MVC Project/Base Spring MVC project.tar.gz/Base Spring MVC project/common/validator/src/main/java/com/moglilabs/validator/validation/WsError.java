package com.moglilabs.validator.validation;

import java.util.Map;


public class WsError {
    private int                 code;
    private String              description;
    private String              message;
    private Map<String, String> errorParams;

    public WsError() {

    }

    public WsError(String description) {
        this.description = description;
    }

    public WsError(int code, String message) {
        this.code = code;
        this.message = message;
        this.description = message;
    }

    public WsError(int code, String message, String description) {
        this.code = code;
        this.message = message;
        this.description = description;
    }

    public WsError(int code, String message, String description, Map<String, String> errorParams) {
        this.code = code;
        this.message = message;
        this.description = description;
        this.errorParams = errorParams;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public Map<String, String> getErrorParams() {
        return errorParams;
    }

    public void setErrorParams(Map<String, String> errorParams) {
        this.errorParams = errorParams;
    }

    @Override
    public String toString() {
        return "WsError [code=" + code + ", description=" + description + ", message=" + message + "]";
    }

}
