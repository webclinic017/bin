package com.moglilabs.validator.exception;

import java.util.ArrayList;
import java.util.List;

import com.moglilabs.validator.validation.WsError;
import com.moglilabs.validator.validation.WsWarning;

public class MoglixException extends Exception {
    

    private static final long serialVersionUID = -6679206462857294333L;
	private List<WsError>   errors   = new ArrayList<WsError>();
    private List<WsWarning> warnings = new ArrayList<WsWarning>();
    private String data;
	
    public MoglixException() {
	}
    
    public MoglixException(List<WsError> errors2) {
		setErrors(errors2);
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public List<WsError> getErrors() {
		return errors;
	}
	public List<WsWarning> getWarnings() {
		return warnings;
	}
	public void setErrors(List<WsError> errors) {
		this.errors = errors;
	}
	public void setWarnings(List<WsWarning> warnings) {
		this.warnings = warnings;
	}

    

}