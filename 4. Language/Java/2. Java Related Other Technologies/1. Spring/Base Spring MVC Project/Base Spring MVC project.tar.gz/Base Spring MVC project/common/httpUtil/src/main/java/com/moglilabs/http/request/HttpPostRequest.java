package com.moglilabs.http.request;

public class HttpPostRequest<T> {

	private String url;
	private T param;

	public HttpPostRequest() {

	}

	public HttpPostRequest(String url) {
		this.url = url;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public T getParam() {
		return param;
	}

	public void setParam(T param) {
		this.param = param;
	}

}
