package com.moglilabs.http.request;

public class HttpGetRequest {

	private String url = "http://www.google.com/search?q=developer";
	
	public HttpGetRequest() {
		
	}

	public HttpGetRequest(String url) {
		this.url = url;
	} 
	
	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
	
	
}
