package com.moglilabs.common.date;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;

public class DateUtil {
	
	public static final String DEFAULT_DATE_TIME_FORMAT = "dd_MMM_yyyy HH:mm:ss.SSS";

	public static java.sql.Timestamp getCurrentDate() {
	    java.util.Date today = new java.util.Date();
	    return new java.sql.Timestamp(today.getTime());
	}

	public static String getCurrentTimeStampString(String format) {
		if(StringUtils.isBlank(format))
			format = DEFAULT_DATE_TIME_FORMAT;
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		String formattedDate = sdf.format(date);
		return formattedDate;
	}
	
	public static Date trimDate(Date date) {
		if(date == null)
			return null;
		
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		c.set(Calendar.HOUR_OF_DAY, 0);
		c.set(Calendar.MINUTE, 0);
		c.set(Calendar.SECOND, 0);
		c.set(Calendar.MILLISECOND, 0);
		return c.getTime();
	}
	
	public static Date getCurrentDateOnly() {
		return trimDate(Calendar.getInstance().getTime());
	}
	
	public static Date convertStringToDate(String str, String format) {
		if(StringUtils.isBlank(str))
			return null;
		if(StringUtils.isBlank(format))
			format = "dd-MM-yyyy";
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		Date d = null;
		try {
			d = sdf.parse(str);
		} catch(Exception e) {
			e.printStackTrace();
		}
		return d;	
	}
	
	public static String convertDateToString(Date date, String format) {
		String dateStr = null;
		if(date == null)
			return null;
		if(StringUtils.isBlank(format))
			format = "dd-MM-yyyy HH:mm:ss";
		SimpleDateFormat sdfr = new SimpleDateFormat(format);
		try {
			dateStr = sdfr.format(date);
		} catch (Exception ex ) {
			System.out.println(ex);
		}
		return dateStr;	
	}
}
