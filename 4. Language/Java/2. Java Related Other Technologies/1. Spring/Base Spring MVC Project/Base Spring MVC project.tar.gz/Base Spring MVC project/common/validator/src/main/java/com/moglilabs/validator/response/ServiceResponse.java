package com.moglilabs.validator.response;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.moglilabs.validator.exception.MoglixException;
import com.moglilabs.validator.validation.WsError;
import com.moglilabs.validator.validation.WsWarning;

public class ServiceResponse implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = -4099479247756971661L;
	
	private boolean			successful;
    private String            message;
    private String            status;
    private List<WsError>     errors;
    private List<WsWarning>   warnings;

    public ServiceResponse() {

    }

    public ServiceResponse(boolean successful, String message) {
        this.successful = successful;
        this.message = message;
    }

    public ServiceResponse(MoglixException ex) {
		this.successful= false;
		this.errors = ex.getErrors();
		this.warnings = ex.getWarnings();
		this.message = ex.getMessage();
	}

	/**
     * @return the successful
     */
    public boolean isSuccessful() {
        return successful;
    }

    /**
     * @param successful the successful to set
     */
    public void setSuccessful(boolean successful) {
        this.successful = successful;
    }

    /**
     * @return the message
     */
    public String getMessage() {
        return message;
    }

    /**
     * @param message the message to set
     */
    public void setMessage(String message) {
        this.message = message;
    }

    public void setErrors(List<WsError> errors) {
        this.errors = errors;
    }

    public List<WsError> getErrors() {
        return errors;
    }

    public ServiceResponse addError(WsError error) {
        if (this.errors == null) {
            this.errors = new ArrayList<WsError>();
        }
        this.errors.add(error);
        return this;
    }

    public ServiceResponse addErrors(List<WsError> errors) {
        if (errors != null) {
            if (this.errors == null) {
                this.errors = new ArrayList<WsError>();
            }
            this.errors.addAll(errors);
        }
        return this;
    }

    public ServiceResponse addWarning(WsWarning warning) {
        if (this.warnings == null) {
            this.warnings = new ArrayList<WsWarning>();
        }
        this.warnings.add(warning);
        return this;
    }

    public ServiceResponse addWarnings(List<WsWarning> warnings) {
        if (warnings != null) {
            if (this.warnings == null) {
                this.warnings = new ArrayList<WsWarning>();
            }
            this.warnings.addAll(warnings);
        }
        return this;
    }

    public void setWarnings(List<WsWarning> warnings) {
        this.warnings = warnings;
    }

    public List<WsWarning> getWarnings() {
        return warnings;
    }

    public boolean hasErrors() {
        return errors != null && errors.size() > 0;
    }

    public boolean hasWarnings() {
        return warnings != null && warnings.size() > 0;
    }

    public void setResponse(ServiceResponse response) {
        this.successful = response.isSuccessful();
        this.message = response.getMessage();
        this.errors = response.getErrors();
        this.warnings = response.getWarnings();
        this.status = response.getStatus();
    }

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
    
    
}
