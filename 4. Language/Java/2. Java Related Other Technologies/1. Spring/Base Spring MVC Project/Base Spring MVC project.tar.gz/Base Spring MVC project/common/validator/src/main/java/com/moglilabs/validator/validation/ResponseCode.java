package com.moglilabs.validator.validation;


public class ResponseCode {

    public static final ResponseCode INVALID_STORE_FEED          = new ResponseCode(1001, "INVALID_FORMAT");
    public static ResponseCode       INVALID_FORMAT              = new ResponseCode(1002, "INVALID_FORMAT");
    public static ResponseCode       MISSING_REQUIRED_PARAMETERS = new ResponseCode(1003, "MISSING_REQUIRED_PARAMETERS");
    public static ResponseCode 		 NOT_FOUND 					 = new ResponseCode(1004, "Item not found");
    public static ResponseCode 		 INVALID_ID 				 = new ResponseCode(10004, "INVALID_ID");
    public static ResponseCode 		 INVALID_REQUIRED_PARAMETERS = new ResponseCode(10005, "REQUIRED PARAMETERS ARE INVALID");
    

    private final int                code;
    private final String             message;

    public ResponseCode(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public int code() {
        return this.code;
    }

    public String message() {
        return this.message;
    }
}
