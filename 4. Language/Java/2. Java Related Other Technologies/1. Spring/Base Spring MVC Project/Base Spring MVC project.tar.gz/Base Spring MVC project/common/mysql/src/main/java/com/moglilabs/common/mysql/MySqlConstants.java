/**
 * @author: Mohit Garg<mohit.garg@moglix.com>
 * @created_on: 07-Sep-2016
 */
package com.moglilabs.common.mysql;

import java.util.Properties;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MySqlConstants {

	@Autowired
	private Properties mysqlProperties;
	
	public static String DATABASE_URL = "";
	public static String DATABASE_USER_NAME = "";
	public static String DATABASE_PASSWORD = "";
	public static String DATABASE_DRIVER = "";
	
	
	@PostConstruct
	public void init(){
	    DATABASE_URL = mysqlProperties.getProperty("mysql.url");
	    DATABASE_USER_NAME = mysqlProperties.getProperty("mysql.username");
	    DATABASE_PASSWORD = mysqlProperties.getProperty("mysql.password");
	    DATABASE_DRIVER = mysqlProperties.getProperty("mysql.driver");
	}
	
}