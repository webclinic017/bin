package com.moglilabs.validator.response;

public class SearchResponse {

	private Long totalCount;
	private Integer pageNumber;
	private Integer pageSize;
	private Integer count;

	public SearchResponse() {

	}

	public SearchResponse(Long totalCount, Integer pageNumber, Integer pageSize, Integer count) {
		this.totalCount = totalCount;
		this.pageNumber = pageNumber;
		this.pageSize = pageSize;
		this.count = count;
	}

	public Long getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(Long totalCount) {
		this.totalCount = totalCount;
	}

	public Integer getPageNumber() {
		return pageNumber;
	}

	public void setPageNumber(Integer pageNumber) {
		this.pageNumber = pageNumber;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}

}
