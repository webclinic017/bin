package com.moglilabs.common.mysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MySqlConnection {
    
    @Autowired
    private MySqlConstants mysqlConstants;

	private static volatile Connection connection = null;
	
	private MySqlConnection() {
		// TODO Auto-generated constructor stub
	}
	
	public Connection getConnection(){
		if(connection != null){
			
				try {
					if(!connection.isValid(3)){
						connection = null;
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
		}
		
		if(connection == null){
			try {
				Class.forName(MySqlConstants.DATABASE_DRIVER);
				String mysqlUrl = MySqlConstants.DATABASE_URL;
				connection = DriverManager.getConnection(mysqlUrl,MySqlConstants.DATABASE_USER_NAME, MySqlConstants.DATABASE_PASSWORD);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return connection;
	}
	
	/*public Connection getConnection(String buyer){
		if(connection == null){
			try {
				Class.forName("com.mysql.jdbc.Driver");
				String mysqlUrl = "jdbc:mysql://"+mysqlProperties.getProperty("mysql.host");
				if(mysqlProperties.getProperty("mysql.port")!="")
					mysqlUrl += ":" + mysqlProperties.getProperty("mysql.port");
				mysqlUrl += "/"+mysqlProperties.getProperty("mysql.buyer_db");
				connection = DriverManager.getConnection(mysqlUrl,mysqlProperties.getProperty("mysql.username"), mysqlProperties.getProperty("mysql.password"));
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return connection;
	}*/
	
	public static void closeConnection(){
		try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/*public static void main(String[] args) {
		Connection connection = MySqlConnection.getConnection();
		if(connection != null)
			System.out.println("Connected to mysql");
	}*/
}
