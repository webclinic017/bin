package com.moglilabs.validator.request;

import java.io.Serializable;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;

import com.moglilabs.validator.constraint.OptionalBlank;
import com.moglilabs.validator.constraint.OptionalNull;
import com.moglilabs.validator.validation.ResponseCode;
import com.moglilabs.validator.validation.ValidationContext;

public class ServiceRequest implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 7457874517601570951L;

	public ValidationContext validate(boolean validateOptionalBlanks) {
        ValidationContext context = new ValidationContext();
        validate(this, context, validateOptionalBlanks);
        return context;

    }

    public ValidationContext validate() {
        return validate(true);
    }

    public static <T> ValidationContext validate(T input, ValidationContext context, boolean validateOptionalBlanks) {
        Set<ConstraintViolation<T>> violations = Validation.buildDefaultValidatorFactory().getValidator().validate(input);
        if (violations.size() > 0) {
            StringBuilder builder = new StringBuilder();
            for (ConstraintViolation<T> violation : violations) {
                if (validateOptionalBlanks || !violation.getConstraintDescriptor().getAnnotation().annotationType().equals(OptionalBlank.class)
                        && !violation.getConstraintDescriptor().getAnnotation().annotationType().equals(OptionalNull.class)) {
                    builder.append(violation.getPropertyPath()).append(' ').append(violation.getMessage()).append('|');
                }
            }
            if (builder.length() > 0) {
                context.addError(ResponseCode.MISSING_REQUIRED_PARAMETERS, builder.deleteCharAt(builder.length() - 1).toString());
            }
        }
        return context;
    }

}
