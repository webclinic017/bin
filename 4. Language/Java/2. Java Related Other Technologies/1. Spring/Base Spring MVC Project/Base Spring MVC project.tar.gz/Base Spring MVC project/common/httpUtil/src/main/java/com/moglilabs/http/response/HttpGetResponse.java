package com.moglilabs.http.response;

import org.apache.http.HttpResponse;

public class HttpGetResponse {

	private Integer statusCode;
	private HttpResponse data;
	private boolean status;

	public Integer getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(Integer statusCode) {
		this.statusCode = statusCode;
	}

	public HttpResponse getData() {
		return data;
	}

	public void setData(HttpResponse data) {
		this.data = data;
	}

	public boolean getStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

}
