package com.moglilabs.http.response;

import com.sun.jersey.api.client.ClientResponse;

public class HttpPostResponse {

	private Integer statusCode;
	private ClientResponse content;
	private boolean status;

	public Integer getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(Integer statusCode) {
		this.statusCode = statusCode;
	}

	public ClientResponse getContent() {
		return content;
	}

	public void setContent(ClientResponse content) {
		this.content = content;
	}

	public boolean getStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}
}
