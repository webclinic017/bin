package com.moglilabs.http.impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.stereotype.Service;
import com.google.gson.Gson;
import com.moglilabs.http.IHttpUtil;
import com.moglilabs.http.request.HttpGetRequest;
import com.moglilabs.http.request.HttpPostRequest;
import com.moglilabs.http.response.HttpGetResponse;
import com.moglilabs.http.response.HttpPostResponse;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

@Service
public class HttpUtilImpl<T> implements IHttpUtil<T> {
		
	public HttpGetResponse sendGet(HttpGetRequest req){
		HttpGetResponse res = new HttpGetResponse();
		HttpClient client = HttpClientBuilder.create().build();
		HttpGet request = new HttpGet(req.getUrl());
		//request.addHeader("User-Agent", USER_AGENT);
		StringBuffer result = new StringBuffer();
		HttpResponse response = null;
		try {
			response = client.execute(request);
			System.out.println("Response Code : " + response.getStatusLine().getStatusCode());
			BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
			
			String line = "";
			while ((line = rd.readLine()) != null) {
				result.append(line);
			}
		} catch(Exception e) {
			
		}
		System.out.println(result.toString());
		res.setData(response);
		//res.setStatus(response.getStatusLine().getReasonPhrase());
		//res.setStatusCode(response.getStatusLine().getStatusCode());
		return res;
	}
	
	public HttpPostResponse sendPostDummy(HttpPostRequest<T> req) {
		/*HttpPostResponse res = new HttpPostResponse();

		HttpClient client = HttpClientBuilder.create().build();
		HttpPost post = new HttpPost(req.getUrl());
		HttpResponse response = null;
		try {
		    //StringEntity se = new StringEntity(new Gson().toJson(req.getData()));
			String data = new Gson().toJson(req.getData());
		    
		    StringEntity params =new StringEntity(data,"UTF-8");
	        params.setContentType("application/json");
		    post.setHeader("Accept", "application/json");
		    post.setHeader("Content-type", "application/json");
		    post.setEntity(params);
			response = client.execute(post);
			if(response.getStatusLine().getStatusCode() == 200) {
				res.setStatus(true);	
			}
		} catch(Exception e) {
		
		}
		res.setData(response);
		return res;*/
		
		return null;
	}
	

	public HttpPostResponse sendPost(HttpPostRequest<T> req) {
		return sendPost(req, null);
	}
	
	public HttpPostResponse sendPost(HttpPostRequest<T> req, Type typeOfSrc) {
		HttpPostResponse res = new HttpPostResponse();
		Client restClient = Client.create();
		String data = "";
		if(typeOfSrc==null)
			data = new Gson().toJson(req.getParam());
		else
			data = new Gson().toJson(req.getParam(), typeOfSrc);
		WebResource webResource = restClient.resource(req.getUrl());
		ClientResponse response = webResource.type("application/json").post(ClientResponse.class, data);
		if(response.getStatus() == 200){
			res.setStatus(true);	
		}
		res.setContent(response);
		return res;
	}
	
	
	@SuppressWarnings("unused")
	private String convertStreamToString(InputStream is) {
	    BufferedReader reader = new BufferedReader(new InputStreamReader(is));
	    StringBuilder sb = new StringBuilder();

	    String line = null;
	    try {
	        while ((line = reader.readLine()) != null) {
	            sb.append(line + "\n");
	        }
	    } catch (IOException e) {
	        e.printStackTrace();
	    } finally {
	        try {
	            is.close();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	    return sb.toString();
	}
}
