package com.moglilabs.validator.validation;

public class WsResponseCode {

    public static ResponseCode INVALID_REQUEST = new ResponseCode(10000, "INVALID_REQUEST");
}
