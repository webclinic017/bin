/**
 * @author: Mohit Garg<mohit.garg@moglix.com>
 * @created_on: 25-Sep-2016
 */
package com.moglilabs.common.mysql.event;

import java.util.Date;

public interface IUpdatedOn {

    public void setUpdatedOn(Date date);
}
