/**
 * @author: Mohit Garg<mohit.garg@moglix.com>
 * @created_on: 25-Sep-2016
 */
package com.moglilabs.common.mysql.event;
import java.util.Date;

import org.hibernate.event.internal.DefaultSaveOrUpdateEventListener;
import org.hibernate.event.spi.SaveOrUpdateEvent;

public class SaveOrUpdateDateListener extends DefaultSaveOrUpdateEventListener{

    private static final long serialVersionUID = -5494314744603346214L;

    @Override
    public void onSaveOrUpdate(SaveOrUpdateEvent event) {
	if (event.getObject() instanceof IUpdatedOn) {
	    IUpdatedOn record = (IUpdatedOn) event.getObject();
	    record.setUpdatedOn(new Date());
	}
	super.onSaveOrUpdate(event);
    }
}
