package com.moglilabs.http;

import java.lang.reflect.Type;

import com.moglilabs.http.request.HttpGetRequest;
import com.moglilabs.http.request.HttpPostRequest;
import com.moglilabs.http.response.HttpGetResponse;
import com.moglilabs.http.response.HttpPostResponse;

public interface IHttpUtil<T> {
	
	public HttpGetResponse sendGet(HttpGetRequest req);
	
	/**
	 * To be used if request object is <b>not</b> of generic type. If request object is of generic type use {@link sendPost(HttpPostRequest<T> req, Type typeOfSrc)}
	 * @param req
	 * @return
	 */
	public HttpPostResponse sendPost(HttpPostRequest<T> req);
	
	/**
	 * To be used if request object is of generic type.
	 * @param req
	 * @param typeOfSrc The specific genericized type of src. You can obtain
     * this type by using the {@link com.google.gson.reflect.TypeToken} class. For example,
     * to get the type for {@code Collection<Foo>}, you should use:
     * <pre>
     * Type typeOfSrc = new TypeToken&lt;Collection&lt;Foo&gt;&gt;(){}.getType();
     * </pre>
	 * @return
	 */
	HttpPostResponse sendPost(HttpPostRequest<T> req, Type typeOfSrc);
}
