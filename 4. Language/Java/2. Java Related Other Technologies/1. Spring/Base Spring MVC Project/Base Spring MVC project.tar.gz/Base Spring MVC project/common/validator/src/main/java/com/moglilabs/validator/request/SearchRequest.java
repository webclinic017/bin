package com.moglilabs.validator.request;

import javax.validation.constraints.NotNull;

public class SearchRequest {

	@NotNull
	private Integer pageNumber = 1;

	@NotNull
	private Integer pageSize = 10;

	private String orderBy = "updatedOn";
	private String order = "desc";

	public Integer getPageNumber() {
		return pageNumber;
	}

	public void setPageNumber(Integer pageNumber) {
		this.pageNumber = pageNumber;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public String getOrderBy() {
		return orderBy;
	}

	public void setOrderBy(String orderBy) {
		this.orderBy = orderBy;
	}

	public String getOrder() {
		return order;
	}

	public void setOrder(String order) {
		this.order = order;
	}

}
